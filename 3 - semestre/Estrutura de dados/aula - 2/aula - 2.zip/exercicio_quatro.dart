main(){
  List listaMaiorNota = [2, 3, 3, 15];
  print(listaMaiorNota.reversed);
}