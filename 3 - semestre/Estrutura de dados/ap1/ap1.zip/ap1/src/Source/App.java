package Source;
// Uma imagem em preto e branco, de tamanho m x n, pode ser representada por uma matriz

//  cujos elementos assumem valores no conjunto {0,1}. Dado um padrão representado por uma matriz 3x3 também
// assumindo valores em {0,1}, escreva um programa que determine se o padrão existe ou não na imagem.

public class App {
    public static void main(String[] args) throws Exception {

        int[][] matrixSize = new int[20][20];
        int[][] buscarMatrix = new int[2][2];
        int[][] matrixCruz = new int[3][3];

        int contador = 0;
        int contadorCruz = 0;

        for (int i = 0; i < matrixSize.length; i++) {
            for (int j = 0; j < matrixSize[i].length; j++) {
                matrixSize[i][j] = (int) Math.round(Math.random());
                System.out.print(" " + matrixSize[i][j] + " ");
            }
            System.out.println();
        }
        buscarMatrix[0][0] = 1;
        buscarMatrix[0][1] = 1;
        buscarMatrix[1][0] = 1;
        buscarMatrix[1][1] = 0;

        matrixCruz[0][0] = 0;
        matrixCruz[0][1] = 1;
        matrixCruz[0][2] = 0;
        matrixCruz[1][0] = 1;
        matrixCruz[1][1] = 1;
        matrixCruz[1][2] = 1;
        matrixCruz[2][0] = 0;
        matrixCruz[2][1] = 1;
        matrixCruz[2][2] = 0;

        System.out.println();
        System.out.println("Padrão a ser encontrado: ");
        for (int i = 0; i < buscarMatrix.length; i++) {
            for (int j = 0; j < buscarMatrix[i].length; j++) {
                System.out.print(" " + buscarMatrix[i][j] + " ");
            }
            System.out.println();
        }

        System.out.println();
        System.out.println("Padrão a ser encontrado: ");

        for (int i = 0; i < matrixCruz.length; i++) {
            for (int j = 0; j < matrixCruz[i].length; j++) {
                System.out.print(" " + matrixCruz[i][j] + " ");
            }
            System.out.println();
        }

        for (int i = 0; i < matrixSize.length - 2; i++) {
            for (int j = 0; j < matrixSize[i].length - 2; j++) {
                if (matrixSize[i][j] == buscarMatrix[0][0]
                        && matrixSize[i][j + 1] == buscarMatrix[0][1]
                        && matrixSize[i + 1][j] == buscarMatrix[1][0]
                        && matrixSize[i + 1][j + 1] == buscarMatrix[1][1]) {
                    contador++;
                }

            }
        }
        Cronometro.start();
        for (int i = 0; i < matrixSize.length - 2; i++) {
            for (int j = 0; j < matrixSize[i].length - 2; j++) {
                if (matrixSize[i][j] == matrixCruz[0][0]
                        && matrixSize[i][j + 1] == matrixCruz[0][1]
                        && matrixSize[i][j + 2] == matrixCruz[0][2]
                        && matrixSize[i + 1][j] == matrixCruz[1][0]
                        && matrixSize[i + 1][j + 1] == matrixCruz[1][1]
                        && matrixSize[i + 1][j + 2] == matrixCruz[1][2]
                        && matrixSize[i + 2][j] == matrixCruz[2][0]
                        && matrixSize[i + 2][j + 1] == matrixCruz[2][1]
                        && matrixSize[i + 2][j + 2] == matrixCruz[2][2]) {
                    contadorCruz++;
                    Cronometro.stop();

                }
            }
        }

        System.out.println();
        if (contador == 0) {
            System.out.println("Padrão normal não encontrado");

        } else {
            System.out.println("Padrao normal encontrado: " + contador + " vezes");
        }

        if (contadorCruz == 0) {
            System.out.println("Padrão cruz teste não encontrado");
        } else {
            System.out.println("Padrao da cruz encontrado: " + contadorCruz + " vezes");
        }
        System.out.println();
        
    }
    
}
